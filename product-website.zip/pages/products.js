import Link from 'next/link'
import { products } from '../data/products'

export default function Products() {
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl mb-4">All Products</h1>
      {/* Filter Buttons */}
      <div className="mb-8 flex gap-4">
        <button className="px-4 py-2 bg-gray-200 rounded">All</button>
        <button className="px-4 py-2 bg-gray-200 rounded">Headphones</button>
        <button className="px-4 py-2 bg-gray-200 rounded">Wearables</button>
      </div>

      {/* Product Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {products.map(product => (
          <div key={product.id} className="border p-4 rounded">
            <img 
              src={product.image} 
              alt={product.name} 
              className="h-48 w-full object-contain"
            />
            <h2 className="text-xl">{product.name}</h2>
            <p>Dhs {product.price.toLocaleString()}</p>
            <Link
              href={`/products/${product.id}`}
              className="text-blue-600 hover:underline"
            >
              View Details
            </Link>
          </div>
        ))}
      </div>
    </div>
  )
}