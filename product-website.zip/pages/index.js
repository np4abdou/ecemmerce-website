import Link from 'next/link'
import { products } from '../data/products'

export default function Home() {
  return (
    <div>
      {/* Hero Section */}
      <div className="mb-16">
        <div className="bg-gray-900 text-white py-20 rounded-xl">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-5xl font-bold mb-4">Premium Tech in UAE</h1>
            <p className="text-xl text-gray-300 mb-8">Discover cutting-edge electronics at competitive prices</p>
            <a 
              href="/products"
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg text-lg transition-colors"
            >
              Shop Now
            </a>
          </div>
        </div>
      </div>

      {/* Featured Products */}
      <div className="container mx-auto p-4">
        <h2 className="text-2xl mb-4">Featured Products</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {products.map(product => (
            <div key={product.id} className="border p-4 rounded">
              <img 
                src={product.image} 
                alt={product.name}
                className="h-48 w-full object-contain"
              />
              <h3 className="text-xl">{product.name}</h3>
              <p>Dhs {product.price.toLocaleString()}</p>
              <Link 
                href={`/products/${product.id}`}
                className="text-blue-600 hover:underline"
              >
                View Details
              </Link>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}