import { useRouter } from 'next/router'
import { products } from '../../data/products'

export default function ProductDetail() {
  const router = useRouter()
  const { id } = router.query
  const product = products.find(p => p.id === Number(id))

  if (!product) return <div>Product not found</div>

  return (
    <div className="container mx-auto p-4">
      <div className="max-w-2xl mx-auto">
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-64 object-contain"
        />
        <h1 className="text-3xl my-4">{product.name}</h1>
        <p className="text-2xl text-gray-700">Dhs {product.price.toLocaleString()}</p>
        <p className="mt-4">{product.description}</p>
        <button 
          className="mt-4 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
          onClick={() => alert('Added to cart!')}
        >
          Add to Cart
        </button>
      </div>
    </div>
  )
}