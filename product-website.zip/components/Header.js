export default function Header() {
    return (
      <header className="bg-gray-900 text-white py-6 shadow-lg">
        <div className="container mx-auto px-4 flex justify-between items-start">
          {/* Navigation Links - Left */}
          <nav className="flex space-x-6">
            <a href="/" className="hover:text-blue-400 transition-colors">Home</a>
            <a href="/products" className="hover:text-blue-400 transition-colors">Collections</a>
            <a href="/contact" className="hover:text-blue-400 transition-colors">Contact Us</a>
          </nav>
  
          {/* Store Title - Right */}
          <div className="text-right">
            <h1 className="text-3xl font-bold tracking-tight">TechEmirate</h1>
            <p className="text-sm text-gray-400 mt-1">Premium Electronics</p>
          </div>
        </div>
      </header>
    )
  }