export const products = [
    {
      id: 1,
      name: "Wireless Headphones",
      price: 799.99,
      description: "Premium noise-canceling wireless headphones",
      image: "/images/shirt.png"
    },
    {
      id: 2,
      name: "Smart Watch",
      price: 1299.99,
      description: "Fitness tracking & heart rate monitor",
      image: "/images/smartwatch.jpg"
    }
  ]