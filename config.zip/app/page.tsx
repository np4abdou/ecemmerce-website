"use client"

import ErrorBoundary from "../components/ErrorBoundary"

export default function SyntheticV0PageForDeployment() {
  return <ErrorBoundary />
}