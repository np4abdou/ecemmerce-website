import Link from "next/link"
import { CheckCircleIcon } from "@heroicons/react/solid"

export default function OrderSuccess() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-100 to-blue-100">
      <div className="bg-white shadow-lg rounded-lg p-8 text-center">
        <CheckCircleIcon className="w-16 h-16 text-green-500 mx-auto mb-4 animate-bounce" />
        <h1 className="text-3xl md:text-4xl font-bold mb-4">Order Submitted!</h1>
        <p className="text-lg md:text-xl mb-6">
          Thank you for your order. We’re processing it and you’ll receive a confirmation soon.
        </p>
        <Link
          href="/"
          className="inline-block bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-md transition-colors"
        >
          Return Home
        </Link>
      </div>
    </div>
  )
}

