import type { JSX } from "react"

export type LangType = "en" | "fr" | "ar"

export interface LocalizedString {
  en: string
  fr: string
  ar: string
}

export interface Category {
  id: string
  name: LocalizedString
  image?: string
}

export interface Theme {
  id: string
  name: LocalizedString
}

export interface SearchSuggestion {
  id: string
  title: LocalizedString
  type: "product" | "category" | "trending"
}

export interface NavItem {
  icon: JSX.Element
  activeIcon: JSX.Element
  label: LocalizedString
  href: string
}

